This is a sample readme file for a simple java project.
