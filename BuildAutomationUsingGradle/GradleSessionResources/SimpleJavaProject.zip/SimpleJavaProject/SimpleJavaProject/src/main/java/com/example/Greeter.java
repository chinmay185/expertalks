package com.example;

public class Greeter {

	public String greet(String name) {
		return "Hello, " + name;
	}
}
