package provider;

public class Provider{

	public static void main(String args[]) {
		System.out.println("In Provider");		
	}
	
	public static String getMessage() {
		String message = "Hello from the provider";
		return message;
	}
}